CODES = {
    0:("Clear Sky"),
    1:("Cloudy Sky"),
    2:("Rainy"),
    3:("Snowy"),
    4:("Hail"),
    5:("Partially Cloudy"),
    6:("Heat Wave"),
    7:("Sleet"),
    8:("Heavy Rain"),
    9:("Windy"),
    10:("Storm"),
}